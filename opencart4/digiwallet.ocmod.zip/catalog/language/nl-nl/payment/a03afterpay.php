<?php
// Text
$_['text_title'] = 'Afterpay';
$_['text_wait'] = 'Even geduld a.u.b.';
