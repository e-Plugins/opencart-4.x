<?php
// Text
$_['text_title'] = 'Visa/Mastercard';
$_['text_wait'] = 'Even geduld a.u.b.';

// Entry
$_['entry_bank_id'] = '&nbsp;&nbsp;Bank:';
