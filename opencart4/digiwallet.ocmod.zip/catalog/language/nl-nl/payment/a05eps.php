<?php
// Text
$_['text_title'] = 'EPS';
$_['text_wait'] = 'Even geduld a.u.b.';