<?php
// Text
$_['text_title'] = 'Afterpay';
$_['text_wait'] = 'Please wait ...';