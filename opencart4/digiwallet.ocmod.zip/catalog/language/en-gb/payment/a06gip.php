<?php
// Text
$_['text_title'] = 'GIP';
$_['text_wait'] = 'Please wait!';