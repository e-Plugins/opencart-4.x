<?php
// Text
$_['text_title'] = 'iDEAL';
$_['text_wait'] = 'Please wait...';

// Entry
$_['entry_bank_id'] = 'Select your bank';
